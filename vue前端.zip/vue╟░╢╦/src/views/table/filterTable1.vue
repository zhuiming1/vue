<template>
  <div>
    <h3>文件管理</h3>
    <p>对文件信息进行筛选。</p>
    <template>
      <el-table
        :data="tableData6"
        style="width: 100%">
        <el-table-column
          prop="directory"
          label="目录"
          :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="capacityUsed"
          label="已用容量"
        :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="capacityLeft"
          label="剩余容量"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="capacityReserved"
          label="预留容量"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="reservedSpaceForReplicas"
          label="保留空间"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="Blocks"
          label="块的个数"
          :formatter="formatter">
        </el-table-column>
           <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button
              size="mini"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>

</script>

<style scoped>

</style>
