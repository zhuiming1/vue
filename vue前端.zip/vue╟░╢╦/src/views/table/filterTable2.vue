<template>
  <div>
    <h3>文件管理</h3>
    <p>对文件信息进行筛选。</p>
    <template>
      <el-table
        :data="tableData7"
        style="width: 100%">
        <el-table-column
          prop="applicationID"
          label="应用程序ID"
          :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="name"
          label="姓名"
        :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="cores"
          label="核心"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="memoryPerNode"
          label="节点内存"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="submittedTime"
          label="提交时间"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="user"
          label="用户"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="state"
          label="状态"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="duration"
          label="时间"
          :formatter="formatter">
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button
              size="mini"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>

</script>

<style scoped>

</style>
