<template>
  <div>
    <h3>文件管理</h3>
    <p>对文件信息进行筛选。</p>
    <template>
      <el-table
        :data="tableData5"
        style="width: 100%">
        <el-table-column
          prop="permission"
          label="许可"
          :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="owner"
          label="所有人"
        :formatter="formatter">
        </el-table-column>
        <el-table-column
          prop="group"
          label="分类"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="size"
          label="文件大小"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="lastModified"
          label="最后修改日期"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="replication"
          label="复制"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="blockSize"
          label="块大小"
          :formatter="formatter">
        </el-table-column>
         <el-table-column
          prop="name"
          label="名称"
          :formatter="formatter">
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button
              size="mini"
              type="danger"
              @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>
<script></script>
<style scoped>

</style>
